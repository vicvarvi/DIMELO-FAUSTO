-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-10-2023 a las 03:23:44
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `fausto`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `Matricula` varchar(20) NOT NULL,
  `Nombre` text NOT NULL,
  `Semestre` int(11) NOT NULL,
  `Estudio` text NOT NULL,
  `Tipo_Alumno` text NOT NULL,
  `Horario` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`Matricula`, `Nombre`, `Semestre`, `Estudio`, `Tipo_Alumno`, `Horario`) VALUES
('VLCAD2231001', 'Joel Mazariegos Zapata', 3, 'Licenciatura en computación administrativa', 'Regular', 'computacion_administrativa_regular'),
('VLICD2231001', 'Cesar Alejandro Lara Ramirez', 3, 'Licenciatura en ingeniería en ciencia de datos', 'Regular', 'Ciencia_datos_regular'),
('VLICD2231002', 'Estefanía De la cruz Bautista', 3, 'Licenciatura en ingeniería en ciencia de datos', 'Regular', 'Ciencia_datos_regular'),
('VLS2231002', 'Victor Manuel Vilchis Varela', 3, 'Licenciatura en ingeniería en sistemas computacionales', 'Irregular', 'sistemas_computacionales_irregular'),
('VLS2231005', 'Arjan Arias Rocher', 3, 'Licenciatura en ingeniería en sistemas computacionales', 'Regular', 'sistemas_computacionales_regular'),
('VLS2231007', 'Javier Hernández May', 3, 'Licenciatura en ingeniería en sistemas computacionales', 'Regular', 'sistemas_computacionales_regular');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clases`
--

CREATE TABLE `clases` (
  `id_clase` int(11) NOT NULL,
  `Nombre_clase` text NOT NULL,
  `Docente` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clases`
--

INSERT INTO `clases` (`id_clase`, `Nombre_clase`, `Docente`) VALUES
(1, 'Estructura de datos', 'Yolanda Cortázar Ramón'),
(2, 'Sistemas de bases de datos', 'Carlos Alonso Noverola Reyes'),
(3, 'Algebra lineal avanzada', 'Carlos Francisco Arias Méndez'),
(4, 'Ingles intermedio', 'Luis Alfonso Hipólito Hernández'),
(5, 'Calculo integral', 'Hermelinda Castillo Bolainas'),
(6, 'Probabilidad multivariable', 'Carlos Francisco Arias Méndez'),
(7, 'Computación estadística', 'Sebastián Madrigal Olán'),
(8, 'Gestión administrativa', 'Matías Jiménez García'),
(9, 'Electricidad y magnetismo ', 'Manuel Acosta Alejandro'),
(10, 'Algebra lineal', 'Cinthia Naty Cortazar Cortazar'),
(11, 'Inteligencia emocional', 'Katya Julissa Zapatero Hernandéz'),
(12, 'Redes computacionales', 'Abel Córdova Palomeque'),
(13, 'Fundamentos de mercadotecnia', 'Jesús Manuel Martínez Montero'),
(14, 'Estadística Descriptiva', 'Carlos Francisco Arias Méndez'),
(15, 'Programación estructurada', 'Carlos Alonso Noverola Reyes'),
(16, 'Fisica', 'Susana Chávez Cruz'),
(17, 'Calculo diferencial', 'María Rossbelfa Vinagre Arias');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `horarios`
--

CREATE TABLE `horarios` (
  `Horario` varchar(50) NOT NULL,
  `Dia` text NOT NULL,
  `id_clase` int(11) NOT NULL,
  `hora_entrada` time(4) NOT NULL,
  `hora_salida` time(4) NOT NULL,
  `salón` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `horarios`
--

INSERT INTO `horarios` (`Horario`, `Dia`, `id_clase`, `hora_entrada`, `hora_salida`, `salón`) VALUES
('Ciencia_datos_regular', 'Lunes', 1, '07:00:00.0000', '09:00:00.0000', 'cc'),
('ciencia_datos_regular', 'Martes', 1, '07:00:00.0000', '09:00:00.0000', 'cc'),
('Sistemas_computacionales_irregular', 'Martes', 15, '10:00:00.0000', '12:00:00.0000', 'cc'),
('Sistemas_computacionales_irregular', 'Martes', 2, '12:00:00.0000', '15:00:00.0000', 'cc'),
('Sistemas_computacionales_irregular', 'Miércoles', 16, '08:00:00.0000', '10:00:00.0000', 'labmec'),
('Sistemas_computacionales_irregular', 'Miércoles', 15, '12:00:00.0000', '13:00:00.0000', 'cc'),
('Sistemas_computacionales_irregular', 'Miércoles', 17, '14:00:00.0000', '16:00:00.0000', 'a101'),
('Sistemas_computacionales_irregular', 'Jueves', 8, '10:30:00.0000', '13:30:00.0000', 'b203'),
('Sistemas_computacionales_irregular', 'Viernes', 17, '07:00:00.0000', '09:00:00.0000', 'b302'),
('Sistemas_computacionales_irregular', 'Viernes', 16, '07:00:00.0000', '09:00:00.0000', 'a304'),
('Sistemas_computacionales_irregular', 'Sábado ', 10, '10:00:00.0000', '13:00:00.0000', 'b401'),
('computacion_administrativa_regular', 'Lunes', 1, '07:00:00.0000', '09:00:00.0000', 'cc'),
('computacion_administrativa_regular', 'Lunes', 11, '09:00:00.0000', '11:00:00.0000', 'a301'),
('computacion_administrativa_regular', 'Lunes', 12, '14:00:00.0000', '17:00:00.3580', 'cc'),
('computacion_administrativa_regular', 'Martes', 1, '07:00:00.0000', '09:00:00.0000', 'cc'),
('computacion_administrativa_regular', 'Martes', 2, '12:00:00.0000', '15:00:00.0000', 'cc'),
('Sistemas_computacionales_regular', 'Lunes', 1, '07:00:00.0000', '09:00:00.0000', 'cc'),
('Sistemas_computacionales_regular', 'Martes', 1, '07:00:00.0000', '09:00:00.0000', 'cc'),
('Ciencia_datos_regular', 'Jueves', 8, '10:30:00.0000', '13:30:00.0000', 'b203'),
('Sistemas_computacionales_regular', 'Sábado ', 10, '10:00:00.0000', '13:00:00.0000', 'b401'),
('Ciencia_datos_regular', 'Martes', 2, '12:00:00.0000', '15:00:00.0000', 'cc'),
('Sistemas_computacionales_regular', 'Martes', 2, '12:00:00.0000', '15:00:00.0000', 'cc'),
('Sistemas_computacionales_regular', 'Miercoles', 4, '14:00:00.0000', '17:00:00.0000', 'a102'),
('computacion_administrativa_regular', 'Miercoles', 4, '14:00:00.0000', '17:00:00.0000', 'a102'),
('Ciencia_datos_regular', 'Miércoles', 3, '11:30:00.0000', '15:30:00.0000', 'a305'),
('Ciencia_datos_regular', 'Jueves', 5, '09:00:00.0000', '10:00:00.9780', 'b305'),
('Sistemas_computacionales_regular', 'Jueves', 5, '09:00:00.2260', '10:00:00.4560', 'b305'),
('Ciencia_datos_regular', 'Viernes', 5, '08:00:00.0000', '10:00:00.0000', 'b303'),
('Sistemas_computacionales_regular', 'Viernes', 5, '08:00:00.0000', '10:00:00.0000', 'b303'),
('Ciencia_datos_regular', 'Jueves', 6, '14:00:00.0000', '15:00:00.0000', 'cc'),
('ciencia_datos_regular', 'Viernes', 6, '10:00:00.0000', '12:00:00.0000', 'a401'),
('Ciencia_datos_regular', 'Lunes', 7, '18:30:00.0000', '20:00:00.0000', 'linea'),
('Ciencia_datos_regular', 'Sábado', 7, '11:00:00.0000', '12:30:00.0000', 'linea'),
('Sistemas_computacionales_regular', 'Jueves', 8, '10:30:00.0000', '13:30:00.0000', 'b203'),
('Sistemas_computacionales_regular', 'Sábado', 9, '07:00:00.0000', '10:00:00.0000', 'b204'),
('computacion_administrativa_regular', 'Miércoles', 13, '10:30:00.0000', '13:30:00.0000', 'b202'),
('computacion_administrativa_regular', 'Sábado', 14, '10:00:00.0000', '13:00:00.0000', 'b304');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`Matricula`),
  ADD KEY `Horario` (`Horario`),
  ADD KEY `Horario_2` (`Horario`);

--
-- Indices de la tabla `clases`
--
ALTER TABLE `clases`
  ADD PRIMARY KEY (`id_clase`),
  ADD KEY `id_clase` (`id_clase`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
