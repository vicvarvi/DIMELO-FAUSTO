from flask import Flask, render_template, request, url_for, redirect, jsonify
from flask_mysqldb import MySQL
import os
import openai
from dotenv import load_dotenv
import json
from transcriber import Transcriber
from llm import LLM
from weather import Weather
from tts import TTS
from pc_command import PcCommand

#Cargar llaves del archivo .env
load_dotenv()
openai.api_key = os.getenv('OPENAI_API_KEY')
elevenlabs_key = os.getenv('ELEVENLABS_API_KEY')

app = Flask(__name__, static_folder='static')
    
    #conexion mysql
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'fausto'
conexion = MySQL(app)

@app.route('/')
def base():
    return redirect(url_for('index'))

@app.route('/Dimelo_Fausto')
def index ():
    return render_template('index.html')

@app.route("/audio", methods=["POST"])
def audio():
    #Obtener audio grabado y transcribirlo
    audio = request.files.get("audio")
    audio.save("audio.mp3")
    audio_file= open("audio.mp3", "rwb")
    transcribed = openai.Audio.transcribe("whisper-1", audio_file)
    
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "Eres un asistente culto pero un poco caricaturesco"},
            {"role": "user", "content": transcribed.text}
        ]
    )

    final_response=''
    for choice in response.choices:
        final_response += choice.message.content

    tts_file = TTS().process(final_response)
    return {"result": "ok","text": final_response, "file": tts_file}

@app.route('/fausto')
def horario_cesar ():
    return render_template('fausto.html')

@app.route('/horario')
def horario_fany ():
    return render_template('horario_fany.html')

@app.route('/horario')
def horario_victor ():
    return render_template('horario_victor.html')

@app.route('/horario_')
def horario_joel ():
    return render_template('horario_joel.html')

@app.route('/horario_a')
def horario_arjan ():
    return render_template('horario_arjan.html')


def pagina_no_encotrada(error):
    #con este se manda a una platilla amigable que infoma de pagina no exisitente
    return render_template('404.html'), 404
    
   #este redirect manda a la pagina principal a todo error
    #return redirect(url_for('index'))

if __name__ =='__main__':
    app.register_error_handler(404, pagina_no_encotrada)
    app.run(debug=True, port=5000)
