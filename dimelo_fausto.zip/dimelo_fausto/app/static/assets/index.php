<!DOCTYPE html>
<html>
<head>
    <title>Mostrar Calificaciones</title>
</head>
<body>
    <h1>Buscar Calificaciones</h1>
    <form action="" method="get">
        Nombre: <input type="text" name="nombre"><br>
        Matrícula: <input type="text" name="matricula"><br>
        <input type="submit" value="Buscar">
    </form>

    <?php
    if (isset($_GET['nombre']) || isset($_GET['matricula'])) {
        $servername = "tu_servidor_mysql";
        $username = "tu_usuario_mysql";
        $password = "tu_contraseña_mysql";
        $database = "fausto.sql";

        $conn = new mysqli($servername, $username, $password, $database);

        if ($conn->connect_error) {
            die("Error de conexión: " . $conn->connect_error);
        }

        $nombre = $_GET['nombre'];
        $matricula = $_GET['matricula'];

        $sql = "SELECT a.Matricula, a.nombre, c.nombre_clase, h.dia, h.hora_entrada, h.hora_salida, h.salon
                FROM alumnos a
                INNER JOIN horarios h ON a.horario = h.id_clase
                INNER JOIN clases c ON h.id_clase = c.id_clase
                WHERE a.nombre = '$nombre' OR a.Matricula = '$matricula'";

        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<h2>Calificaciones:</h2>";
            echo "<table>";
            echo "<tr><th>Nombre</th><th>Nombre de Clase</th><th>Día</th><th>Hora de Entrada</th><th>Hora de Salida</th><th>Salón</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['nombre'] . "</td>";
                echo "<td>" . $row['nombre_clase'] . "</td>";
                echo "<td>" . $row['dia'] . "</td>";
                echo "<td>" . $row['hora_entrada'] . "</td>";
                echo "<td>" . $row['hora_salida'] . "</td>";
                echo "<td>" . $row['salon'] . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No se encontraron calificaciones.";
        }

        $conn->close();
    }
    ?>
</body>
</html>