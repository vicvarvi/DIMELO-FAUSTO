// main.js

document.addEventListener('DOMContentLoaded', function() {
    // Tu código aquí
    navigator.mediaDevices.getUserMedia({ audio: true })
        .then(function(stream) {
            // El micrófono está autorizado, puedes hacer algo con el flujo de audio
        })
        .catch(function(error) {
            // Manejar el error (puede ser causado por la denegación del permiso)
        });
});
